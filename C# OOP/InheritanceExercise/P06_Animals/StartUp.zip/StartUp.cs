﻿using P06_Animals.Core;
using System;

namespace P06_Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
