﻿using P05_MordorsCruelPlan.Core;
using System;

namespace P05_MordorsCruelPlan
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
