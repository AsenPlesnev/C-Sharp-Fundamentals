﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_MordorsCruelPlan.Moods
{
    public class Mood
    {
        public virtual string Name => "Mood";
    }
}
