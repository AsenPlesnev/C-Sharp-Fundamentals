﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_MordorsCruelPlan.Moods
{
    public class Sad : Mood
    {
        public override string Name => "Sad";
    }
}
